﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour {

    [SerializeField]
    private float speed = 5f;
    private CharacterController controller;
    private float verticalVelocity;
    [SerializeField]
    private float gravity = 15f;
    [SerializeField]
    private float jumpForce = 10f;
    private Animator anim;
    private int frameCount = 0;
    private bool isDead = false;
    [SerializeField]
    private Text distanceText;
    private float increaseZone = 200f;
	// Use this for initialization
	void Start () {
        anim = GetComponent<Animator>();
        controller = GetComponent<CharacterController>();
	}
	
	// Update is called once per frame
	void Update () {
        if (isDead)
            return;

        if (controller.velocity.z <= 0)
            frameCount++;
        else
            frameCount = 0;
        if (transform.position.y <= -1)
            frameCount = 21;
        if (frameCount >= 20)
            Death();

        if(transform.position.z > increaseZone)
        {   
            if(speed <= 30)
            {
                speed *= 1.2f;
                increaseZone *= 2;
            }
        }

        distanceText.text = ((int)transform.position.z).ToString()+"m";

        Vector3 moveVector;
        //X
        moveVector.x = Input.GetAxis("Horizontal") * speed;
        //Y
        if(controller.isGrounded)
        {
            verticalVelocity = -0.5f;
            if (Input.GetKeyDown(KeyCode.Space))
                verticalVelocity = jumpForce;
        }
        else
        {
            verticalVelocity -= gravity * Time.deltaTime;
        }
        moveVector.y = verticalVelocity;
        //Z
        moveVector.z = speed;
        controller.Move(moveVector * Time.deltaTime);

        anim.SetBool("Grounded", controller.isGrounded);
    }
    void Death()
    {
        isDead = true;
        anim.enabled = false;
    }
}
