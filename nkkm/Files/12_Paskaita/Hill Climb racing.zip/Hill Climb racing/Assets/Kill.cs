﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Kill : MonoBehaviour {

	void OnCollisionEnter2D(Collision2D coll)
    {
        if(coll.gameObject.CompareTag("Chasis"))
        {
            Debug.Log("Hit");
        }
    }
}
