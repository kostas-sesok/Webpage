﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarController : MonoBehaviour {

    public float speed = 500;

    public WheelJoint2D backWheel;
    public WheelJoint2D frontWheel;

    private float movement = 0f;
    
	// Update is called once per frame
	void Update () {
        movement = -Input.GetAxisRaw("Horizontal") * speed;
	}
    private void FixedUpdate()
    {
        if(movement == 0f)
        {
            backWheel.useMotor = false;
            frontWheel.useMotor = false;
        }
        else
        {
            backWheel.useMotor = true;
            frontWheel.useMotor = true;

            JointMotor2D motor = new JointMotor2D { motorSpeed = movement, maxMotorTorque = 10000 };
            backWheel.motor = motor;
            frontWheel.motor = motor;


        }
    }

}
