﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour {
    // Objektas kuri seksime su kamera
    public Transform target;

	// LateUpdate kaip ir update suveikia kiekviena kadra, bet visada suveikia po update.
    // LateUpdate naudojame tam, kad zaidejas jau butu atlikes visus savo veiksums ir
    // tada su kamera mes galesime priarteti iki jo ta kadra
	void LateUpdate () {
        // i newPos kintamaji issaugojam sekamo objekto pozicija
        Vector3 newPos = target.position;
        // pakeiciam newPos z ir y pozicijas
        newPos.z = -10;
        newPos.y = 0.7f;
        // priligyname kameros pozicija musu newPos kintamojo pozicijai
        transform.position = newPos;
	}
}
