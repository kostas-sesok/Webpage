﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pauze : MonoBehaviour {
    
    public GameObject PausePanel;
    private bool isPaused = false;

	// Update is called once per frame
	void Update () {
		if(Input.GetKeyDown(KeyCode.Escape))
        {
            if(isPaused)
            {
                isPaused = false;
                Time.timeScale = 1;
                PausePanel.SetActive(false);
            }
            else if(!isPaused)
            {
                isPaused = true;
                Time.timeScale = 0;
                PausePanel.SetActive(true);
            }
        }
	}
}
