﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    [SerializeField]
    private float moveSpeed = 5f;
    private CharacterController controller;
    [SerializeField]
    private float gravity = 12f;
    private float verticalVelocity;
    [SerializeField]
    private float jumpForce = 10f;

	// Use this for initialization
	void Start () {
        controller = GetComponent<CharacterController>();
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 moveVector;
        // X
        moveVector.x = Input.GetAxis("Horizontal") * moveSpeed;
        // Y
        if(controller.isGrounded)
        {
            verticalVelocity = -0.5f;
            if(Input.GetKeyDown(KeyCode.Space))
            {
                verticalVelocity = jumpForce;
            }
        }
        else
        {
            verticalVelocity -= gravity * Time.deltaTime;
        }
        moveVector.y = verticalVelocity;
        // Z
        moveVector.z = moveSpeed;
        controller.Move(moveVector * Time.deltaTime);
	}
}
