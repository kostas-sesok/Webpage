﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BirdSpawner : MonoBehaviour {
    //Gameobjektu masyvai, skirti pauksciu prefabam saugoti
    public GameObject[] birdsLeft;
    public GameObject[] birdsRight;
    //intervalas per kuri spawninsis musu pauksciai
    public float SpawnTime = 1.5f;
	// Use this for initialization
	void Start () {
        //Iskvieciam Spawn funckija kas tam tikra intervala
        InvokeRepeating("Spawn", 0, SpawnTime);
	}
    void Spawn()
    {   //Sukuriam pauksti kuris skris i kaire
        Instantiate(birdsLeft[0], new Vector3(11f, Random.Range(-5, 5), 0f), Quaternion.identity);
        //Sukuriam pauksti kuris skris i desine
        Instantiate(birdsRight[0], new Vector3(-11f, Random.Range(-5, 5), 0f), Quaternion.identity);
    }

}
