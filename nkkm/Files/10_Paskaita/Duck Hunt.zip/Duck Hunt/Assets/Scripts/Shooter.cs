﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooter : MonoBehaviour {

	// Update is called once per frame
	void Update () {
        //tikriname kada ivyko peles paspaudimas
		if(Input.GetMouseButtonDown(0))
        {   
            // uzfiksuojame kur ekrane buvo paspausta ir konvertuojame gautas reiksmes
            // is pixeliu i Unity pasaulio koordinates(transform)
            Vector3 mousePosInWorld = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            // Sukuriam lazeri kuris sauna nuo musu paspausto tasko gilyn(z asis) 20 vienetu
            RaycastHit2D hit = Physics2D.Raycast(mousePosInWorld, Vector3.forward, 20f);
            //tikriname jei pataikeme i objekta su collider komponentu
            if(hit.collider!=null)
            {   //pridedam gravitacijos, kad pradetu kristi
                hit.rigidbody.gravityScale = 2f;
                // isjungiam birdfly(script) ir Animator komponentus
                hit.transform.GetComponent<BirdFly>().enabled = false;
                hit.transform.GetComponent<Animator>().enabled = false;
                //sunaikiname nusauta objekta po 4 sekundziu
                Destroy(hit.collider.gameObject, 4f);             
            }
        }
	}
}
