﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class Timer : MonoBehaviour {

    //laikas sekundemis
    public float timer = 100f;
    //suapvalintas laikas, kadangi float reiksmes turi daug skaciu po kablelio
    private int roundedTimer;
    //textas atvaizduoti laikmati
    public Text timeText;

	// Update is called once per frame
	void Update () {
        //atiminejam laika is timer'io
        timer -= Time.deltaTime;
        //suapvaliname laika, kad neliktu skaiciu po kablelio
        roundedTimer = (int)timer;
        //atvaizduojam suapvalinta laika
        timeText.text = roundedTimer.ToString();
        //jei laikas baigesi, restartuojame scena
        if (timer <= 0)
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
	}
}
