﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BirdFly : MonoBehaviour {
    //kintamasis Rigidbody2D komponentui saugoti
    private Rigidbody2D rb2d;
    //pauksciu skridimo greitis
    public float speed = 5f;
	// Use this for initialization
	void Start () {
        //issaugojam Rigidbody2d komponenta i rb2d kintamaji
        rb2d = GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
        //judinam pauksti keisdami jo velocity
        rb2d.velocity = Vector2.right * speed;
	}
    private void OnTriggerEnter2D(Collider2D collision)
    {   //Jei paukstis patenka i Destroyer objekta
        if (collision.gameObject.tag == "Destroy")
            //Sunaikiman pauksti
            Destroy(gameObject);
    }
}
