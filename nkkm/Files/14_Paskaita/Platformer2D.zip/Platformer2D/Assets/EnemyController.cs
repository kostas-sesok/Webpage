﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EnemyController : MonoBehaviour {

    public float speed = 3f;
    private Rigidbody2D rb2d;

    public bool Left = true;

    public float radius = 0.1f;
    public LayerMask WhatIsWall;
    public GameObject center;

	// Use this for initialization
	void Start () {
        rb2d = GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
        bool isHittingWall = Physics2D.OverlapCircle(center.transform.position, radius, WhatIsWall);
        if (isHittingWall)
            Left = !Left;
        if (Left)
        {
            rb2d.velocity = Vector2.left * speed;
            transform.localScale = new Vector3(1, 1, 1);
        }
        else
        {
            rb2d.velocity = Vector2.right * speed;
            transform.localScale = new Vector3(-1, 1, 1);
        }
            
	}
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

}
