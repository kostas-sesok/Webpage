﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class ChangeLevel : MonoBehaviour {

    public string LevelName;
    private bool canChangeLevel = false;
    public GameObject levelNameCanvas;
	// Update is called once per frame
	void Update () {
		if(canChangeLevel && Input.GetKeyDown(KeyCode.Return))
        {
            SceneManager.LoadScene(LevelName);
        }
	}
    private void OnTriggerEnter2D(Collider2D collision)
    {
        levelNameCanvas.SetActive(true);
        canChangeLevel = true;
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        levelNameCanvas.SetActive(false);
        canChangeLevel = false;
    }
}
