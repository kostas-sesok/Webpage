﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoodSpawner : MonoBehaviour {

    // Maisto objektas kuri spawninsim
    public GameObject foodPrefab;

    // Visu keturiu sienu Transformai tam kad zinoti ju pozicijas zaidime (ribom nustatyti)
    public Transform borderTop;
    public Transform borderBottom;
    public Transform borderLeft;
    public Transform borderRight;
	
	// Update is called once per frame
	void Update () {
        // Tikrinam ar yra scenoje maisto, jei nera, pagaminam nauja
		if(GameObject.FindGameObjectsWithTag("Food").Length == 0)
        {   
            // Sugeneruojam x ir y koordinates
            double x = Random.Range(borderLeft.position.x, borderRight.position.x);
            double y = Random.Range(borderBottom.position.y, borderTop.position.y);
            // Suapvalinam jas iki vieno skaitmens po kablelio (pvz 3.2)
            x = System.Math.Round(x, 1);
            y = System.Math.Round(y, 1);
            // Apvalinimas gali vykti i didesne puse todel yra bug'as jog kartais maistas
            // atsiduria sienoje, todel mum reikia padaryti toki elementaru tikrinima
            if (x > 0)
                x -= 0.1;
            else if (x < 0)
                x += 0.1;
            if (y > 0)
                y -= 0.1;
            else if (y < 0)
                y += 0.1;
            // Sutvarke koordinates galima pagaminti maista scenoje.
            Instantiate(foodPrefab, new Vector2((float)x, (float)y), Quaternion.identity);
        }
	}
}
