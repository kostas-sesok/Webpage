﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
// System.Linq reikalingas musu listo funkcijai Last()
using System.Linq;

public class SnakeController : MonoBehaviour {

    // Vectorius gyvateles krypciai nustatyti
    private Vector2 direction = Vector2.right;
    // List'as, sekti gyvateles uodegos ilgi, pirma ir paskutini elementa
    public List<Transform> tail = new List<Transform>();
    // bool kintamasis, kad zinoti kada mes suvalgeme maista
    bool ate = false;
    // Prefab'as, kad turetume is ko pagaminti(spawnint'i) gyvateles uodega
    public GameObject tailPrefab;
    // AudioSource valgymo garsui issaugoti
    public AudioSource eatSound;

	// Use this for initialization
	void Start () {
        // InvokeRepeating  pastoviai kviecia funkcija atsizvelgiant i musu nurodyta intervala
        InvokeRepeating("Move", 0.15f, 0.15f);
	}
	
	// Update is called once per frame
	void Update () {
        // Sios salygos atsizvelgia i tai kas buvo paspausta ant klaviaturos ir pakeicia musu
        // krypties vektoriu i atitinkama krypti
        if (Input.GetKey(KeyCode.LeftArrow) && direction != Vector2.right)
            direction = Vector2.left;
        else if (Input.GetKey(KeyCode.DownArrow) && direction != Vector2.up)
            direction = Vector2.down;
        else if (Input.GetKey(KeyCode.RightArrow) && direction != Vector2.left)
            direction = Vector2.right;
        else if (Input.GetKey(KeyCode.UpArrow) && direction != Vector2.down)
            direction = Vector2.up;

	}
    // judejimo funkcija
    void Move()
    {   
        // GapPos kintamasis issaugo tuscia vieta gyvateles galvai pajudejus
        Vector2 GapPos = transform.position;
        // Judinam gyvateles galva su Translate metodu, tai yra tiesiog keiciam jos transform komponento pozicijas
        transform.Translate(direction * 0.1f);
        //kas vyksta jei suvalgem maista
        if(ate)
        {   // Sukuriam papildoma uodegos gabaliuka tuscioje vietoje tarp gyvateles galvos ir likusios uodegos
            GameObject tailClone = Instantiate(tailPrefab, GapPos, Quaternion.identity);
            // Pridedam ta informacija i List'a kad yra naujas sukurtas gabaliukas
            tail.Insert(0, tailClone.transform);
            // padare visus veiksmus ate kintamaji grazinam i pradine reiksme
            ate = false;
        }
        // jeigu nesuvalgom ta kadra nieko ir jau turime uodega tai
        else if(tail.Count > 0)
        {   // paimam paskutini uodegos gabaliuka ir idedam ji i tuscia vieta tarp galvos ir uodegos
            tail.Last().position = GapPos;
            // pridedam ta informacija i list'a, perkeldami paskutini uodegos gabaliuka i prieki
            tail.Insert(0, tail.Last());
            // istrinam paskutini uodegos gabaliuka
            tail.RemoveAt(tail.Count - 1);
        }
    }
    // Funkcija kuri suveikia kai patenkam i kito objekto collider 2d trigger zona
    void OnTriggerEnter2D(Collider2D collision)
    {   
        // jeigu susidurem su maistu
        if(collision.gameObject.tag == "Food")
        {   
            // aktyvuojam ate bool'a
            ate = true;
            // sunaikiname maista is scenos
            Destroy(collision.gameObject);
            // paleidziame suvalgymo garsa
            eatSound.Play();
        }
        // jeigu susidurem su kazkuo kitu nei maistas
        else
        {   // perkrauname scena
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }
}
