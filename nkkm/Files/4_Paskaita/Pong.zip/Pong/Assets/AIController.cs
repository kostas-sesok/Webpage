﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIController : MonoBehaviour {
    
    // Bot'o padalos greitis
    public float Speed = 2f;
    // Kamuolio objektas is scenos, tam kad zinotume kamuoliu pozicija scenoje
    public GameObject Ball;

	void Update () {
        // Issaugome Kamuolio Y asies pozicija is scenos
        float ballYPos = Ball.transform.position.y;
        // Apskaiciuojame kiek turetu padala pajudeti per viena kadra(frame'a)
        float step = Speed * Time.deltaTime;
        // Apskaiciuojame busima padalos pozicija nurodydami
        // nuo kur reikia judeti (transform.position.y)
        // link kur reikia judeti (ballYPos) 
        // Kokiu greiciau reikia judeti (step)
        float currentYPos = Mathf.MoveTowards(transform.position.y, ballYPos, step);
        // Priskiriame objektui jo nauja pozicija
        transform.position = new Vector3(transform.position.x, Mathf.Clamp(currentYPos, -4.1f, 4.1f), transform.position.z);
	}
}
