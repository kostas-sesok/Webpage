﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    // Musu zaidejo greitis
    public float Speed = 5;
    // Kintamasis Rigidbody2D komponentui issaugoti
    private Rigidbody2D rb2d;

	void Start () {
        // Paimam Rigidbody2D komponenta nuo zaidejo padalos ir issaugom ji rb2d kintamajame
        rb2d = GetComponent<Rigidbody2D>();
	}
	void Update () {
        // I vertical kintamaji issaugojame reiksme kurios intervalas [-1, 1]. Si reiksme mum parodo kokie klavisai yra spaudziami 
        //((W ar S) arba (Rodykle i virsu ar Rodykle i apacia))
        float vertical = Input.GetAxisRaw("Vertical");
        //Priskiarem greiti musu padalai paimdami jos Rigidbody2D velocity reiksme
        rb2d.velocity = new Vector2(0, vertical * Speed);
        //Apribojam padalos pozicija, kad ji negaletu iseiti uz ekrano ribu (Mathf.Clamp) funkcija
        transform.position = new Vector3(transform.position.x,Mathf.Clamp(transform.position.y,-4.1f,4.1f),transform.position.z);
	}
}
