﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallController : MonoBehaviour {

    // Kintamasis Rigidbody2D komponentui issaugoti
    private Rigidbody2D rb2d;

	// Use this for initialization
	void Start () {
        // Paimam Rigidbody2D komponenta nuo kamuolio ir issaugom ji rb2d kintamajame
        rb2d = GetComponent<Rigidbody2D>();
        // Duodam kamuoliui pradines jegos. 500 vienetu x asyje ir 100 y asyje
        rb2d.AddForce(new Vector2(500, 100));
	}
	
	// Update is called once per frame
	void Update () {
        // Apribojam kamuolio maximalu greiti, kad kamuoliukas nepradetu per greitai sokineti
        rb2d.velocity = new Vector2(Mathf.Clamp(rb2d.velocity.x, -13.5f, 13.5f), Mathf.Clamp(rb2d.velocity.y,-4.5f,4.5f));

        // Apribojam kamuolio minimalu greiti x'o asyje, jei jis per mazas padidinam ji 1.25 karto
        if (Mathf.Abs(rb2d.velocity.x) < 9)
            rb2d.velocity = new Vector2(rb2d.velocity.x * 1.25f , rb2d.velocity.y);
        // Apribojam kamuolio minimalu greiti y'o asyje, jei jis per mazas padidinam ji 1.25 karto
        if (Mathf.Abs(rb2d.velocity.y) < 1.9f)
            rb2d.velocity = new Vector2(rb2d.velocity.x, rb2d.velocity.y * 1.25f);
    }

    // Unity speciali funkcija, kuri suveikia visada kai objektas atsitrenkia i kita objekta su Collider2D komponentu
    void OnCollisionEnter2D(Collision2D collision)
    {   
        // tikrinam ar objektas i kuri atsitrenkem turi tag'a "Paddle"
        if(collision.gameObject.tag =="Paddle")
        {   
            // Paimam ir issaugojam padalos greiti y asyje,kai kamuolys atsitrenke i padala
            float PaddleVelocity = collision.gameObject.GetComponent<Rigidbody2D>().velocity.y;
            // Jeigu musu sugalvoti scenarijai yra tiesa, tai pakeiciam kamuoliuko trajektorija i priesinga
            if ((PaddleVelocity < 0 && rb2d.velocity.y > 0) || (PaddleVelocity > 0 && rb2d.velocity.y < 0))
                rb2d.velocity = new Vector2(rb2d.velocity.x, -rb2d.velocity.y);
        }
        // Pridedam siek tiek atsitiktinumo faktoriaus musu kamuoliukui panaudojant Random.Range metoda.
        rb2d.velocity = new Vector2(rb2d.velocity.x + Random.Range(-0.1f, 0.1f), rb2d.velocity.y + Random.Range(-0.1f, 0.1f));
    }

}
