﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColumnSpawner : MonoBehaviour {
    // intervalas kas kiek laiko atsiras vis nauja kolona
    public float interval = 2f;
    // Musu jau is anksto sukurtas kolonu objektas su visais 
    // nustatymais ir reikalingais komponentais
    public GameObject columnPrefab;

	// Use this for initialization
	void Start () {
        // Paleidziam funkcija spawn kas nurodyta laiko intervala
        InvokeRepeating("Spawn", 0, interval);
	}
    void Spawn()
    {   // Sukuriam kolonu objekta su Instantiate()
        // paduodame tris parametrus: objekta kuri sukursim, pozicija, rotaticja
        Instantiate(columnPrefab,
            new Vector3(transform.position.x, Random.Range(-3f, 2f), transform.position.z),
            Quaternion.identity);
    }
}
