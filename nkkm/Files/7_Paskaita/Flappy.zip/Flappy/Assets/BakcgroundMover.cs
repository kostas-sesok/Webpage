﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BakcgroundMover : MonoBehaviour {
    // fono judejimo greitis
    public float speed = 5f;

	// Update is called once per frame
	void Update () {
        // apskaiciojam sekancia offset parametro reiksme
        Vector2 offset = new Vector2(Time.time * speed, 0);
        // priligyname sia reiksme materialo maintextureoffset parametrui
        GetComponent<Renderer>().material.mainTextureOffset = offset;
	}
}
