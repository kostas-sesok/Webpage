﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour {
    // paukscio pakelimo jega
    public float force = 250f;
    // texto objekto kintamieji
    public Text scoreText;
    public Text HighScoreText;
    // Tasku kintamieji
    private int Score;
    private int HighScore = 0;
    // Rigidbody2D komponento kintamasis
    private Rigidbody2D rb2d;

    void Start() {
       // prilyginam kiekvieno zaidimo pradzioje taskus nuliui
        Score = 0;
        // I highscore kintamaji issaugojame praeitu zaidimu geriausia rezultata
        // Paimdami ji is PlayerPrefs klases su raktu "HighScore"
        HighScore = PlayerPrefs.GetInt("HighScore");
        // Atvaizduojam taskus tekste
        scoreText.text = Score.ToString();
        HighScoreText.text = HighScore.ToString();
        // pasiemam ir issaugojam rigidbody2d komponenta i kintamaji rb2d
        rb2d = GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
        // tikriname kada paspaudziamas kairys peles mygtukas
        // indeksas 0, kai paspaudziamas duodam pauksciui jegos vertikalia kryptimi
        if (Input.GetMouseButtonDown(0))
            rb2d.AddForce(Vector2.up * force);
	}
    // kai patenka paukstis i Trigger colliderio zona (siame zaidime taip skaiciuojame taskus)
    private void OnTriggerEnter2D(Collider2D collision)
    {   // pridedam taska
        Score++;
        // jei surinkom daugiau tasku nei geriausias rezultatas tai
        if (Score > HighScore)
        {   // perrasom geriausia rezultata ir issuagom playerPrefs
            // klaseje su raktu "HighScore"
            HighScore = Score;
            PlayerPrefs.SetInt("HighScore", HighScore);
        }
        // atvaizduojam taskus tekstiniuose objektuose  
        scoreText.text = Score.ToString();
        HighScoreText.text = HighScore.ToString();
    }
    // Jei atsitrenkiam i paprasta collideri(kolonos, sienos)
    private void OnCollisionEnter2D(Collision2D collision)
    {   // restartuojam dabartine scena
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
