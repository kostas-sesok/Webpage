﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ColumnMover : MonoBehaviour {
    // kolonos greitis
    public float speed = 2f;
    private Rigidbody2D rb2d;

	// Use this for initialization
	void Start () {
        // issaugojam rigidbody2d komponenta i rb2d kintamaji 
        rb2d = GetComponent<Rigidbody2D>();
	}

    // Update is called once per frame
    void Update()
    {   // duodam kolonom judejimo jegos, kad judetu link zaidejo(i kaire)
        rb2d.velocity = Vector3.left * speed;
    }
    // Jei kolonos papuola i colliderio trigger zona
    private void OnTriggerEnter2D(Collider2D collision)
    {   // jei ta trigger zona turi tag'a "Destroy"
        if (collision.gameObject.tag == "Destroy")
            // sunaikiname kolonu objekta
            Destroy(gameObject);
    }
}
