﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    public float speed = 5;
    private Rigidbody2D rb2d;

	// Use this for initialization
	void Start () {
        //Imam komponenta nuo padalos ir saugom kintamajam rb2d
        rb2d = GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
        // paspaudimai w ir s arba rodykle i virsu arba i apacia bus uzfiskuojami
        // vertical kintamasis igis reiksme nuo -1 iki 1.
        float vertical = Input.GetAxisRaw("Vertical");
        rb2d.velocity = new Vector2(0, vertical * speed);
        transform.position = new Vector3(transform.position.x, Mathf.Clamp(transform.position.y, -4.1f, 4.1f), transform.position.z);
	}
}
