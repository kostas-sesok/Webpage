﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIController : MonoBehaviour {

    public float speed = 2f;
    public GameObject ball;
	
	// Update is called once per frame
	void Update () {
        float ballYPos = ball.transform.position.y;
        float step = speed * Time.deltaTime;
        float CurrentYPos = Mathf.MoveTowards(transform.position.y, ballYPos, step);
        transform.position = new Vector3(transform.position.x, Mathf.Clamp(CurrentYPos, -4.1f, 4.1f), transform.position.z);
	}
}
