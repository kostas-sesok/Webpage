﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallController : MonoBehaviour {

    private Rigidbody2D rb2d;
    // sukuriam kintamaji GameManager skripto informacijai issaugoti
    private GameManager GM;

	// Use this for initialization
	void Start () {
        // Surandam objekta kuris turi komponenta GameManager ir issaugojam
        // to komponento nuoroda GM kintamajame
        GM = FindObjectOfType<GameManager>();
        rb2d = GetComponent<Rigidbody2D>();
        // Prasidejus zaidimui nunulinam visas kamuolio jegas
        rb2d.velocity = Vector2.zero;
    }
	
	// Update is called once per frame
	void Update () {
        // Tikriname, jeigu kamuoliukas nejuda ir paspaudziam enter klavisa
        if(Input.GetKeyDown(KeyCode.Return) && rb2d.velocity == Vector2.zero)
        {   
            // pridedam kamuoliukui jegos
            rb2d.AddForce(new Vector2(500, 100));
        }

        rb2d.velocity = new Vector2(Mathf.Clamp(rb2d.velocity.x, -13.5f, 13.5f), Mathf.Clamp(rb2d.velocity.y, -4.5f, 4.5f));
        if (Mathf.Abs(rb2d.velocity.x) < 9.5f)
            rb2d.velocity = new Vector2(rb2d.velocity.x * 1.5f, rb2d.velocity.y);
        if (Mathf.Abs(rb2d.velocity.y) < 1.95f)
            rb2d.velocity = new Vector2(rb2d.velocity.x, rb2d.velocity.y * 1.5f);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Paddle")
        {
            float PaddleVelocity = collision.gameObject.GetComponent<Rigidbody2D>().velocity.y;
            if ((PaddleVelocity < 0 && rb2d.velocity.y > 0) || (PaddleVelocity > 0 && rb2d.velocity.y < 0))
                rb2d.velocity = new Vector2(rb2d.velocity.x, -rb2d.velocity.y);
        }
        rb2d.velocity = new Vector2(rb2d.velocity.x + Random.Range(-0.1f, 0.1f), rb2d.velocity.y + Random.Range(-0.1f, 0.1f));
    }
    // Unity speciali funkcija, kuri suveikia kai objektas su collideriu patenka i colliderio trigger zona
    private void OnTriggerEnter2D(Collider2D collision)
    {   
        // jeigu patekom i desines sienos trigger zona
        if (collision.gameObject.name == "DesineSiena")
        {   
            // pridedam zaidejui taska
            GM.AddPlayerScore();
        }
        // jeigu patekom i kaires sienos trigger zona
        if (collision.gameObject.name == "KaireSiena")
        {   
            // pridedam botui taska
            GM.AddAIScore();
        }
        // Restartuojam kamuoliuka iskviesdami ResetBall funkcija kuria paraseme GameManager skripte-
        GM.ResetBall();
    }

}
