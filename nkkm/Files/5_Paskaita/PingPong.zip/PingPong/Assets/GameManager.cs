﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// pridedam namespace'a kuris leis naudoti UI elementus scripte
using UnityEngine.UI;

public class GameManager : MonoBehaviour {

    // sukuriam 2 Text tipo kintamuosius, kad galetume parodyti skriptui 
    // kuriu objektu teksta mes keisim
    public Text PlayerPointsText;
    public Text AIPointsText;

    // sukuriam kintamuosius taskam skaiciuoti
    private int PlayerPoints;
    private int AIPoints;

    // sukuriam GameObject tipo kintamaji Kamuoliui issaugoti
    // kamuoliu sitame skripte mum reikia kad galetumeme restartuoti zaidima
    public GameObject Ball;

	// Use this for initialization
	void Start () {
        // Pradzioje zaidimo prilyginam abieju zaideju taskus 0
        PlayerPoints = 0;
        AIPoints = 0;
	}
    void Update()
    {   
        // atvaizduojam abieju zaideju taskus scenoje
        PlayerPointsText.text = PlayerPoints.ToString();
        AIPointsText.text = AIPoints.ToString();
    }
    // funkcija zaidejo taskam prideti
    public void AddPlayerScore()
    {  
        PlayerPoints++;
    }
    // funkcija boto taskam prideti
    public void AddAIScore()
    {
        AIPoints++;
    }
    // funkcija kuri grazina kamuoliuka i pradine busena kai yra imusamas taskas
    public void ResetBall()
    {   
        // grazinam kamuoli i pradine pozicija (0,0,0) 
        Ball.transform.position = Vector3.zero;
        // nuresetinam kamuolio jegas, padarom kad butu lygios nuliui.----
        Ball.GetComponent<Rigidbody2D>().velocity = Vector2.zero;
    }


}
