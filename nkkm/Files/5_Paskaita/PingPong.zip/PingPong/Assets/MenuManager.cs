﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// Pridedam papildoma namespace'a kuris leis mum keisti scenas
using UnityEngine.SceneManagement;

public class MenuManager : MonoBehaviour {

    // funkcija butinai turi buti public kad galetumeme ja matyti is mygtuko
	public void StartGame()
    {   
        // Keiciam scena i "Main"
        SceneManager.LoadScene("Main");
    }
    public void QuitGame()
    {   // Uzdarom zaidima, veiks tik tada kai zaidima subuildinsim
        Application.Quit();
    }
}
