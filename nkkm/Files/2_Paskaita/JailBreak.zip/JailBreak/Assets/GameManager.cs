﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour {

    public Text storyText;

    private bool arRadoRakta;

    private enum Kambariai
    { 
        room1, room1a, room1b,room2,room3,room3a,room4,finish
    };

    Kambariai kambarys;

	// Use this for initialization
	void Start () {
        arRadoRakta = false;
        kambarys = Kambariai.room1;
        storyText.text = "Hello world";
	}
	
	// Update is called once per frame
	void Update () {
        if (kambarys == Kambariai.room1)
            Kambarys1();
        else if (kambarys == Kambariai.room1a)
            Kambarys1a();
        else if (kambarys == Kambariai.room1b)
            Kambarys1b();
        else if (kambarys == Kambariai.room2)
            Kambarys2();
        else if (kambarys == Kambariai.room3)
            Kambarys3();
        else if (kambarys == Kambariai.room3a)
            Kambarys3a();
        else if (kambarys == Kambariai.room4)
            Kambarys4();
        else if (kambarys == Kambariai.finish)
            Finish();
	}
    void Kambarys1()
    {
        storyText.text = "Tu istrigai kalejime, tau reikia pabegti" +
               "Tu matai 3 koridorius. Jei nori eiti i virsu, spausk W," +
               "jeigu nori eiti zemyn, spausk S, jeigu nori eiti i prieki" +
               "spausk D";
        if (Input.GetKeyDown(KeyCode.S))
            kambarys = Kambariai.room1b;
        else if (Input.GetKeyDown(KeyCode.W))
            kambarys = Kambariai.room1a;
        else if (Input.GetKeyDown(KeyCode.D))
            kambarys = Kambariai.room2;
    }
    void Kambarys1a()
    {
        storyText.text = "Tu nuejai i virsu (Room1a), cia nieko neradai" +
               "Jei nori eiti atgal , spausk A";
        if (Input.GetKeyDown(KeyCode.A))
            kambarys = Kambariai.room1;
    }
    void Kambarys1b()
    {
        storyText.text = "tu dabar esi room1b, cia nieko nera." +
            "jei nori gristi spausk A";
        if (Input.GetKeyDown(KeyCode.A))
            kambarys = Kambariai.room1;
    }
    void Kambarys2()
    {
        storyText.text = "Dabar tu esi room2. nuo cia gali eiti pirmyn ir atgal" +
            "Jei nori eiti tiesiai spausk D, jei nori eiti atgal spausk A";
        if (Input.GetKeyDown(KeyCode.D))
            kambarys = Kambariai.room3;
        if (Input.GetKeyDown(KeyCode.A))
            kambarys = Kambariai.room1;
    }
    void Kambarys3()
    {
        storyText.text = "dabar kambarys 3. jei nori eiti pirmyn spausk D" +
            "jei nori gristi spausk A, jei nori eiti i baisu kambari apacioje, spausk S";
        if (Input.GetKeyDown(KeyCode.D))
            kambarys = Kambariai.room4;
        if (Input.GetKeyDown(KeyCode.A))
            kambarys = Kambariai.room2;
        if (Input.GetKeyDown(KeyCode.S))
            kambarys = Kambariai.room3a;
    }
    void Kambarys3a()
    {
        storyText.text = "tu esi kambary 3a. tu radai ant zemes gulinti rakta ir ji pasiemei" +
            "jei nori gristi spausk A";
        arRadoRakta = true;
        if (Input.GetKeyDown(KeyCode.A))
            kambarys = Kambariai.room3;
        
    }
    void Kambarys4()
    {   
        if(arRadoRakta == true)
        {
            storyText.text = "tu matai priesais save uzrakintas duris. Jei nori atrakinti spausk R";
            if (Input.GetKeyDown(KeyCode.R))
                kambarys = Kambariai.finish;
        }
        else
        {
            storyText.text = "tu matai priesais save duris. Jos uzrakintos. turbut reikia rasti rakta" +
                "jei nori gristi spausk A";
            if (Input.GetKeyDown(KeyCode.A))
                kambarys = Kambariai.room3;
        }
            
    }
    void Finish()
    {
        storyText.text = "Sveikiname. Pabegai is kalejimo. Jei nori zaisti dar karta, spausk R";
        if(Input.GetKeyDown(KeyCode.R))
        {
            kambarys = Kambariai.room1;
            arRadoRakta = false;
        }
    }
}
