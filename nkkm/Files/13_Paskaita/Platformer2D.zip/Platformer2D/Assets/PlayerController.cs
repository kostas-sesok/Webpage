﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    public float speed = 5f;
    public float jumpSpeed = 10f;
    private Rigidbody2D rb2d;
    private Animator anim;

    public LayerMask whatIsGround;
    public float radius = 0.1f;
    public GameObject groundPoint;
    private bool isGrounded = false;
	// Use this for initialization
	void Start () {
        rb2d = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
        isGrounded = Physics2D.OverlapCircle(groundPoint.transform.position, radius, whatIsGround);
        

        float horizontal = Input.GetAxis("Horizontal") * speed;
        rb2d.velocity = new Vector2(horizontal,rb2d.velocity.y);

        if (isGrounded && Input.GetKeyDown(KeyCode.Space))
            rb2d.velocity = new Vector2(rb2d.velocity.x, jumpSpeed);

        if (horizontal > 0)
            transform.localScale = new Vector3(1, 1, 1);
        else if(horizontal < 0)
            transform.localScale = new Vector3(-1, 1, 1);

        anim.SetFloat("Speed", Mathf.Abs(horizontal));
        anim.SetBool("Grounded", isGrounded);
    }
}
