﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    public float releaseTime = 0.15f;
    public float maxDragDistance = 2f;
    private Rigidbody2D rb2d;
    public Rigidbody2D hook;
    public GameObject nextBall;
    private bool isPressed = false;
    // Use this for initialization
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        if (isPressed)
        {
            Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            if (Vector3.Distance(mousePos, hook.position) > maxDragDistance)
                rb2d.position = hook.position + (mousePos - hook.position).normalized * maxDragDistance;
            else
                rb2d.position = mousePos;

        }
    }
    private void OnMouseDown()
    {
        isPressed = true;
        rb2d.isKinematic = true;
    }
    private void OnMouseUp()
    {
        isPressed = false;
        rb2d.isKinematic = false;
        StartCoroutine(Release());
    }
    IEnumerator Release()
    {
        yield return new WaitForSeconds(releaseTime);
        GetComponent<SpringJoint2D>().enabled = false;
        enabled = false;
        yield return new WaitForSeconds(3f);
        if(nextBall != null)
        {
            nextBall.SetActive(true);
        }
        else
        {
            Debug.Log("No more shots left");
        }

    }
}
