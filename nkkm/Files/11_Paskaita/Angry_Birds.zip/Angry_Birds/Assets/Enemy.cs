﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {
    public float health = 5f;
    public static int EnemiesAlive = 0;
    public GameObject DeathParticles;
	// Use this for initialization
	void Start () {
        EnemiesAlive++;
	}
	void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.relativeVelocity.magnitude > health)
        {
            Instantiate(DeathParticles, transform.position, Quaternion.identity);

            EnemiesAlive--;
            if (EnemiesAlive <= 0)
                Debug.Log("You win");
            Destroy(gameObject);
        }
    }
}
