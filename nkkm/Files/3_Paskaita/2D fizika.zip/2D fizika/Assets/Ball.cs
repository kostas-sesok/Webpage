﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour {

    private Rigidbody2D rb2d;
    public float speed;

	// Use this for initialization
	void Start () {
        rb2d = GetComponent<Rigidbody2D>();
	}
	
	// Update is called once per frame
	void Update () {
        // a <- = -1 
        // d -> = 1
        // nieko = 0
        float horizontal = Input.GetAxis("Horizontal");
        rb2d.AddForce(new Vector2(horizontal * speed,0));

	}
}
